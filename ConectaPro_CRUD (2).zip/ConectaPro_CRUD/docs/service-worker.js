/**
 * Service Worker do ConectaPro.
 *
 * Armazena os arquivos principais em cache
 * para permitir acesso offline a pagina.
 */

const CACHE_NAME = "conectapro-v2";

const ARQUIVOS_CACHE = [
    "./",
    "./index.html",
    "./style.css",
    "./script.js",
    "./manifest.json",
    "./icon.svg",
    "./icon-192.png",
    "./icon-512.png"
];

/**
 * Instala o Service Worker e armazena
 * os arquivos principais no cache.
 */
self.addEventListener("install", (evento) => {

    evento.waitUntil(

        caches.open(CACHE_NAME).then((cache) => {

            return cache.addAll(ARQUIVOS_CACHE);

        })

    );

    self.skipWaiting();

});

/**
 * Ativa o Service Worker e remove
 * caches antigos.
 */
self.addEventListener("activate", (evento) => {

    evento.waitUntil(

        caches.keys().then((nomesCaches) => {

            return Promise.all(

                nomesCaches.map((nomeCache) => {

                    if (nomeCache !== CACHE_NAME) {

                        return caches.delete(nomeCache);

                    }

                })

            );

        })

    );

    self.clients.claim();

});

/**
 * Intercepta requisicoes e utiliza
 * os arquivos armazenados em cache.
 */
self.addEventListener("fetch", (evento) => {

    if (evento.request.method !== "GET") {
        return;
    }

    evento.respondWith(

        caches.match(evento.request).then((respostaCache) => {

            if (respostaCache) {
                return respostaCache;
            }

            return fetch(evento.request);

        })

    );

});
