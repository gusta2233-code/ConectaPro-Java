/**
 * JavaScript da Landing Page ConectaPro.
 *
 * Faz duas coisas: registra o Service Worker (base do PWA)
 * e mostra o botão "Instalar aplicativo" quando o navegador permite.
 */

// Guarda o evento de instalação para usá-lo quando o usuário clicar no botão.
let eventoInstalacao = null;

document.addEventListener("DOMContentLoaded", () => {
    registrarServiceWorker();
    configurarInstalacao();
});

/** Registra o Service Worker, que guarda a página em cache para uso offline. */
function registrarServiceWorker() {
    if (!("serviceWorker" in navigator)) {
        console.log("Este navegador não oferece suporte a Service Worker.");
        return;
    }

    window.addEventListener("load", () => {
        navigator.serviceWorker.register("./service-worker.js")
            .then((registro) => console.log("Service Worker registrado:", registro.scope))
            .catch((erro) => console.error("Erro ao registrar Service Worker:", erro));
    });
}

/**
 * O navegador avisa (beforeinstallprompt) quando o app pode ser instalado.
 * Nesse momento o botão aparece; ao clicar, abrimos a janela de instalação.
 */
function configurarInstalacao() {
    const botao = document.getElementById("botao-instalar");

    window.addEventListener("beforeinstallprompt", (evento) => {
        evento.preventDefault();
        eventoInstalacao = evento;
        botao.hidden = false;
    });

    botao.addEventListener("click", async () => {
        if (!eventoInstalacao) {
            return;
        }
        eventoInstalacao.prompt();
        await eventoInstalacao.userChoice;
        eventoInstalacao = null;
        botao.hidden = true;
    });

    // Depois de instalado, o botão não faz mais sentido.
    window.addEventListener("appinstalled", () => {
        botao.hidden = true;
    });
}
