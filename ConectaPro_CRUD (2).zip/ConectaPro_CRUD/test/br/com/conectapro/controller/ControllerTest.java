package br.com.conectapro.controller;

import br.com.conectapro.models.Categoria;
import br.com.conectapro.models.Cliente;
import br.com.conectapro.models.Profissional;
import br.com.conectapro.models.TipoUsuario;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Testes da validação feita nos Controllers.
 * Os erros acontecem antes de chamar o banco, então estes testes não precisam do MySQL.
 */
class ControllerTest {

    private final Profissional profissional =
            new Profissional(1, "Pedro", "pedro@teste.com", "hash", null, "Joinville", "SC");
    private final Cliente cliente =
            new Cliente(2, "Ana", "ana@teste.com", "hash", null, "Joinville", "SC");

    @Test
    void servicoComPrecoNaoNumericoEhRejeitado() {
        ServicoController controller = new ServicoController();

        IllegalArgumentException erro = assertThrows(IllegalArgumentException.class,
                () -> controller.cadastrar(profissional, "Pintura", "Sala e quarto", Categoria.PINTOR, "abc"));

        assertTrue(erro.getMessage().contains("Preço inválido"));
    }

    @Test
    void servicoExigeUmProfissionalComoDono() {
        ServicoController controller = new ServicoController();

        assertThrows(IllegalArgumentException.class,
                () -> controller.cadastrar(cliente, "Pintura", "Sala", Categoria.PINTOR, "100"));
    }

    @Test
    void solicitacaoExigeUmClienteComoDono() {
        SolicitacaoController controller = new SolicitacaoController();

        assertThrows(IllegalArgumentException.class,
                () -> controller.cadastrar(profissional, null, "Título", "Descrição", "Joinville", "SC"));
    }

    @Test
    void usuarioComEmailInvalidoEhRejeitado() {
        PessoaController controller = new PessoaController();

        IllegalArgumentException erro = assertThrows(IllegalArgumentException.class,
                () -> controller.cadastrar(TipoUsuario.CLIENTE, "Ana", "sem-arroba", "", "Joinville", "SC", "123456"));

        assertEquals("E-mail inválido.", erro.getMessage());
    }
}
