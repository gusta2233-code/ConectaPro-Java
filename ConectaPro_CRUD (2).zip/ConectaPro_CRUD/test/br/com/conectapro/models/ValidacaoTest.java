package br.com.conectapro.models;

import br.com.conectapro.util.SenhaUtil;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Testes das regras de validação (sem banco de dados).
 * Mostram que dados inválidos são barrados antes de chegar ao MySQL.
 */
class ValidacaoTest {

    @Test
    void emailInvalidoEhRejeitado() {
        Cliente cliente = new Cliente();
        assertThrows(IllegalArgumentException.class, () -> cliente.setEmail("email-sem-arroba"));
    }

    @Test
    void emailValidoEhGravadoEmMinusculas() {
        Cliente cliente = new Cliente();
        cliente.setEmail("  Maria@Teste.COM ");
        assertEquals("maria@teste.com", cliente.getEmail());
    }

    @Test
    void estadoPrecisaTerDuasLetras() {
        Profissional profissional = new Profissional();
        assertThrows(IllegalArgumentException.class, () -> profissional.setEstado("SCA"));
        profissional.setEstado("sc");
        assertEquals("SC", profissional.getEstado());
    }

    @Test
    void nomeEmBrancoEhRejeitado() {
        Cliente cliente = new Cliente();
        assertThrows(IllegalArgumentException.class, () -> cliente.setNome("   "));
    }

    @Test
    void precoDoServicoPrecisaSerMaiorQueZero() {
        Servico servico = new Servico();
        assertThrows(IllegalArgumentException.class, () -> servico.setPreco(BigDecimal.ZERO));
        assertThrows(IllegalArgumentException.class, () -> servico.setPreco(new BigDecimal("-10")));
    }

    @Test
    void solicitacaoExigeTituloEClienteValidos() {
        Solicitacao solicitacao = new Solicitacao();
        assertThrows(IllegalArgumentException.class, () -> solicitacao.setTitulo(""));
        assertThrows(IllegalArgumentException.class, () -> solicitacao.setCliente(null));
    }

    @Test
    void tipoDoUsuarioDependeDaSubclasse() {
        assertEquals(TipoUsuario.CLIENTE, new Cliente().getTipo());
        assertEquals(TipoUsuario.PROFISSIONAL, new Profissional().getTipo());
    }

    @Test
    void equalsEHashCodeUsamEmailParaPessoasEIdParaServicos() {
        Cliente a = new Cliente(1, "Ana", "ana@teste.com", "h", null, "Joinville", "SC");
        Cliente b = new Cliente(2, "Ana Maria", "ANA@teste.com", "h", null, "Joinville", "SC");
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());

        Servico s1 = new Servico();
        Servico s2 = new Servico();
        s1.setId(7);
        s2.setId(7);
        assertEquals(s1, s2);
        s2.setId(8);
        assertNotEquals(s1, s2);
    }

    @Test
    void categoriaDesconhecidaViraOutros() {
        assertEquals(Categoria.PEDREIRO, Categoria.deTexto("Pedreiro"));
        assertEquals(Categoria.OUTROS, Categoria.deTexto("Categoria inexistente"));
    }

    @Test
    void senhaCurtaEhRejeitadaESenhaValidaViraHash() {
        assertThrows(IllegalArgumentException.class, () -> SenhaUtil.gerarHash("123"));

        String hash = SenhaUtil.gerarHash("senha123");
        assertNotEquals("senha123", hash);
        assertTrue(hash.startsWith("PBKDF2$"));
        // O salt é aleatório: a mesma senha gera hashes diferentes.
        assertNotEquals(hash, SenhaUtil.gerarHash("senha123"));
    }
}
