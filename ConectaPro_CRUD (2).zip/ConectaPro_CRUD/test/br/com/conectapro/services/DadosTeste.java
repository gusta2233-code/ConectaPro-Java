package br.com.conectapro.services;

import br.com.conectapro.models.Categoria;
import br.com.conectapro.models.Cliente;
import br.com.conectapro.models.Profissional;
import br.com.conectapro.models.Servico;
import br.com.conectapro.models.Solicitacao;

import java.math.BigDecimal;

/** Cria objetos válidos para os testes (e-mails únicos, para não colidir com dados reais). */
final class DadosTeste {

    private DadosTeste() {
    }

    static Cliente novoCliente() {
        return new Cliente(0, "Cliente Teste", "cliente." + System.nanoTime() + "@teste.com",
                "hash-de-teste", "48999990000", "Florianópolis", "SC");
    }

    static Profissional novoProfissional() {
        return new Profissional(0, "Profissional Teste", "prof." + System.nanoTime() + "@teste.com",
                "hash-de-teste", "48988880000", "Florianópolis", "SC");
    }

    /** Serviço de eletricista ligado ao profissional informado (que já deve estar no banco). */
    static Servico novoServico(Profissional dono) {
        Servico servico = new Servico();
        servico.setProfissional(dono);
        servico.setNome("Instalação elétrica de teste");
        servico.setDescricao("Troca de tomadas e disjuntores");
        servico.setCategoria(Categoria.ELETRICISTA);
        servico.setPreco(new BigDecimal("150.00"));
        return servico;
    }

    /** Solicitação sem serviço, ligada ao cliente informado (que já deve estar no banco). */
    static Solicitacao novaSolicitacao(Cliente dono) {
        Solicitacao solicitacao = new Solicitacao();
        solicitacao.setCliente(dono);
        solicitacao.setTitulo("Trocar chuveiro elétrico");
        solicitacao.setDescricao("Chuveiro queimou e precisa de troca");
        solicitacao.setCidade("Florianópolis");
        solicitacao.setEstado("SC");
        return solicitacao;
    }
}
