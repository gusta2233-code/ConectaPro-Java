package br.com.conectapro.services;

import br.com.conectapro.models.Categoria;
import br.com.conectapro.models.Profissional;
import br.com.conectapro.models.Servico;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Testes de integração do Service (JDBC) do CRUD de serviços.
 * Também verificam o relacionamento: todo serviço pertence a um profissional.
 */
class ServicoServiceTest {

    private final PessoaService pessoaService = new PessoaService();
    private final ServicoService service = new ServicoService();

    private Profissional dono;
    private Servico servico; // o serviço criado no teste (apagado na limpeza)

    /** Todo serviço precisa de um profissional: cria um antes de cada teste. */
    @BeforeEach
    void preparar() throws SQLException {
        dono = DadosTeste.novoProfissional();
        pessoaService.cadastrar(dono);
        servico = null;
    }

    /** Apaga primeiro o serviço e depois o profissional (por causa da chave estrangeira). */
    @AfterEach
    void limpar() throws SQLException {
        if (servico != null) {
            service.excluir(servico.getId());
        }
        pessoaService.excluir(dono.getId());
    }

    private Servico cadastrarServico() throws SQLException {
        servico = DadosTeste.novoServico(dono);
        service.cadastrar(servico);
        return servico;
    }

    /** Procura um serviço na listagem; devolve null se não existir. */
    private Servico buscar(int id) throws SQLException {
        for (Servico s : service.listar()) {
            if (s.getId() == id) {
                return s;
            }
        }
        return null;
    }

    @Test
    void cadastrarGravaNoBancoEGeraId() throws SQLException {
        Servico criado = cadastrarServico();

        assertTrue(criado.getId() > 0);
        assertNotNull(buscar(criado.getId()));
    }

    @Test
    void listarTrazOServicoComOProfissionalDono() throws SQLException {
        Servico criado = cadastrarServico();

        Servico encontrado = buscar(criado.getId());

        assertNotNull(encontrado);
        assertEquals(Categoria.ELETRICISTA, encontrado.getCategoria());
        assertEquals(dono.getId(), encontrado.getProfissional().getId());
        assertEquals(dono.getNome(), encontrado.getProfissional().getNome());
    }

    @Test
    void atualizarAlteraOsDadosNoBanco() throws SQLException {
        Servico criado = cadastrarServico();

        criado.setNome("Serviço Alterado");
        criado.setCategoria(Categoria.PEDREIRO);
        criado.setPreco(new BigDecimal("200.50"));
        service.atualizar(criado);

        Servico atualizado = buscar(criado.getId());
        assertEquals("Serviço Alterado", atualizado.getNome());
        assertEquals(Categoria.PEDREIRO, atualizado.getCategoria());
        assertEquals(0, new BigDecimal("200.50").compareTo(atualizado.getPreco()));
    }

    @Test
    void excluirRemoveOServicoDoBanco() throws SQLException {
        Servico criado = cadastrarServico();

        service.excluir(criado.getId());

        assertNull(buscar(criado.getId()));
    }
}
