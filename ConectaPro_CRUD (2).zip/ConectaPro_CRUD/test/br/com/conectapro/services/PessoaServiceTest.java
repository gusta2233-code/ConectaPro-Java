package br.com.conectapro.services;

import br.com.conectapro.models.Cliente;
import br.com.conectapro.models.Pessoa;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Testes de integração do Service (JDBC) do CRUD de usuários.
 * Precisam do MySQL ligado, do script banco/conectapro.sql executado e do config.properties.
 */
class PessoaServiceTest {

    private final PessoaService service = new PessoaService();
    private final List<Integer> criados = new ArrayList<>();

    /** Cadastra um cliente de teste e guarda o id para a limpeza. */
    private Cliente cadastrarCliente() throws SQLException {
        Cliente cliente = DadosTeste.novoCliente();
        service.cadastrar(cliente);
        criados.add(cliente.getId());
        return cliente;
    }

    /** Procura um usuário na listagem; devolve null se não existir. */
    private Pessoa buscar(int id) throws SQLException {
        for (Pessoa p : service.listar()) {
            if (p.getId() == id) {
                return p;
            }
        }
        return null;
    }

    /** Apaga o que o teste criou, para o banco ficar como estava. */
    @AfterEach
    void limpar() throws SQLException {
        for (int id : criados) {
            service.excluir(id);
        }
    }

    @Test
    void cadastrarGravaNoBancoEGeraId() throws SQLException {
        Cliente cliente = cadastrarCliente();

        assertTrue(cliente.getId() > 0);
        assertNotNull(buscar(cliente.getId()));
    }

    @Test
    void listarRetornaOUsuarioCadastrado() throws SQLException {
        Cliente cliente = cadastrarCliente();

        Pessoa encontrada = buscar(cliente.getId());

        assertNotNull(encontrada);
        assertEquals(cliente.getEmail(), encontrada.getEmail());
        assertEquals(cliente.getTipo(), encontrada.getTipo());
    }

    @Test
    void atualizarAlteraOsDadosNoBanco() throws SQLException {
        Cliente cliente = cadastrarCliente();

        cliente.setNome("Nome Alterado");
        cliente.setCidade("São José");
        service.atualizar(cliente);

        Pessoa atualizada = buscar(cliente.getId());
        assertEquals("Nome Alterado", atualizada.getNome());
        assertEquals("São José", atualizada.getCidade());
    }

    @Test
    void excluirRemoveOUsuarioDoBanco() throws SQLException {
        Cliente cliente = cadastrarCliente();

        service.excluir(cliente.getId());

        assertNull(buscar(cliente.getId()));
    }
}
