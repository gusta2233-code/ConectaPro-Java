package br.com.conectapro.services;

import br.com.conectapro.models.Cliente;
import br.com.conectapro.models.Profissional;
import br.com.conectapro.models.Servico;
import br.com.conectapro.models.Solicitacao;
import br.com.conectapro.models.StatusSolicitacao;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Testes de integração do Service (JDBC) do CRUD de solicitações.
 * Também verificam os relacionamentos: a solicitação pertence a um cliente
 * e pode estar ligada a um serviço.
 */
class SolicitacaoServiceTest {

    private final PessoaService pessoaService = new PessoaService();
    private final ServicoService servicoService = new ServicoService();
    private final SolicitacaoService service = new SolicitacaoService();

    private Cliente cliente;
    private Profissional profissional;
    private Servico servico;
    private Solicitacao solicitacao; // a solicitação criada no teste (apagada na limpeza)

    /** Cria o cliente, o profissional e o serviço de que as solicitações dependem. */
    @BeforeEach
    void preparar() throws SQLException {
        cliente = DadosTeste.novoCliente();
        pessoaService.cadastrar(cliente);

        profissional = DadosTeste.novoProfissional();
        pessoaService.cadastrar(profissional);

        servico = DadosTeste.novoServico(profissional);
        servicoService.cadastrar(servico);

        solicitacao = null;
    }

    /** Apaga na ordem inversa da criação, por causa das chaves estrangeiras. */
    @AfterEach
    void limpar() throws SQLException {
        if (solicitacao != null) {
            service.excluir(solicitacao.getId());
        }
        servicoService.excluir(servico.getId());
        pessoaService.excluir(profissional.getId());
        pessoaService.excluir(cliente.getId());
    }

    private Solicitacao cadastrarSolicitacao() throws SQLException {
        solicitacao = DadosTeste.novaSolicitacao(cliente);
        service.cadastrar(solicitacao);
        return solicitacao;
    }

    /** Procura uma solicitação na listagem; devolve null se não existir. */
    private Solicitacao buscar(int id) throws SQLException {
        for (Solicitacao s : service.listar()) {
            if (s.getId() == id) {
                return s;
            }
        }
        return null;
    }

    @Test
    void cadastrarGravaNoBancoComStatusAberta() throws SQLException {
        Solicitacao criada = cadastrarSolicitacao();

        assertTrue(criada.getId() > 0);
        Solicitacao encontrada = buscar(criada.getId());
        assertNotNull(encontrada);
        assertEquals(StatusSolicitacao.ABERTA, encontrada.getStatus());
    }

    @Test
    void listarTrazOClienteDaSolicitacaoESemServicoQuandoOpcional() throws SQLException {
        Solicitacao criada = cadastrarSolicitacao();

        Solicitacao encontrada = buscar(criada.getId());

        assertEquals(cliente.getId(), encontrada.getCliente().getId());
        assertNull(encontrada.getServico());
    }

    @Test
    void atualizarAlteraStatusELigaOServico() throws SQLException {
        Solicitacao criada = cadastrarSolicitacao();

        criada.setServico(servico);
        criada.setStatus(StatusSolicitacao.EM_ANDAMENTO);
        criada.setTitulo("Título Alterado");
        service.atualizar(criada);

        Solicitacao atualizada = buscar(criada.getId());
        assertEquals(StatusSolicitacao.EM_ANDAMENTO, atualizada.getStatus());
        assertEquals("Título Alterado", atualizada.getTitulo());
        assertEquals(servico.getId(), atualizada.getServico().getId());
    }

    @Test
    void excluirRemoveASolicitacaoDoBanco() throws SQLException {
        Solicitacao criada = cadastrarSolicitacao();

        service.excluir(criada.getId());

        assertNull(buscar(criada.getId()));
    }
}
