/** Interações da landing page ConectaPro. */
document.addEventListener('DOMContentLoaded', () => {
  const header = document.querySelector('.cabecalho');
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.links');
  const navLinks = document.querySelectorAll('.links a');

  const updateHeader = () => header.classList.toggle('scrolled', window.scrollY > 12);
  updateHeader();
  window.addEventListener('scroll', updateHeader, { passive: true });

  toggle.addEventListener('click', () => {
    const opened = toggle.getAttribute('aria-expanded') === 'true';
    toggle.setAttribute('aria-expanded', String(!opened));
    toggle.setAttribute('aria-label', opened ? 'Abrir menu' : 'Fechar menu');
    nav.classList.toggle('open', !opened);
  });

  navLinks.forEach(link => link.addEventListener('click', () => {
    nav.classList.remove('open');
    toggle.setAttribute('aria-expanded', 'false');
    toggle.setAttribute('aria-label', 'Abrir menu');
    navLinks.forEach(item => item.classList.remove('active'));
    link.classList.add('active');
  }));

  // Atualiza o link ativo de acordo com a seção visível.
  const sections = document.querySelectorAll('main section[id]');
  if ('IntersectionObserver' in window) {
    const sectionObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          navLinks.forEach(link => link.classList.toggle('active', link.getAttribute('href') === `#${entry.target.id}`));
        }
      });
    }, { rootMargin: '-35% 0px -55% 0px' });
    sections.forEach(section => sectionObserver.observe(section));
  }
  // Spotlight colorido com rastro: as posições anteriores do cursor deixam
  // pequenas áreas de cor que desaparecem gradualmente.
  const hero = document.querySelector('.inicio');
  if (hero) {
    const trail = [];
    const trailDuration = 1450;
    let current = null;
    let frameId = 0;
    let lastSampleAt = 0;

    const clamp = value => Math.max(0, Math.min(1, value));

    const renderSpotlight = now => {
      if (!current) {
        frameId = 0;
        return;
      }

      const rect = hero.getBoundingClientRect();
      const gradients = [];

      // A área sob o cursor usa exatamente o mesmo tamanho e degradê do rastro.
      gradients.push(
        `radial-gradient(circle 112px at ${current.x}px ${current.y}px, ` +
        `rgba(0,0,0,.68) 0px, rgba(0,0,0,.42) 65px, transparent 112px)`
      );

      // Pontos anteriores formam um rastro orgânico atrás do ponteiro.
      for (const point of trail) {
        const age = now - point.time;
        const life = clamp(1 - age / trailDuration);
        if (life <= 0) continue;

        const radius = 112;
        const alpha = (0.68 * Math.pow(life, 1.25)).toFixed(3);
        const midAlpha = (0.42 * Math.pow(life, 1.25)).toFixed(3);
        gradients.push(
          `radial-gradient(circle ${radius}px at ${point.x}px ${point.y}px, ` +
          `rgba(0,0,0,${alpha}) 0px, rgba(0,0,0,${midAlpha}) 65px, transparent ${radius}px)`
        );
      }

      hero.style.setProperty('--spot-mask', gradients.join(','));
      // Mantém a animação do esmaecimento do rastro até ele desaparecer.
      const hasLiveTrail = trail.some(point => now - point.time < trailDuration);
      if (hasLiveTrail) {
        frameId = requestAnimationFrame(renderSpotlight);
      } else {
        frameId = 0;
        trail.length = 0;
      }
    };

    const moveSpotlight = event => {
      if (event.pointerType === 'touch') return;

      const rect = hero.getBoundingClientRect();
      const next = {
        x: Math.max(0, Math.min(rect.width, event.clientX - rect.left)),
        y: Math.max(0, Math.min(rect.height, event.clientY - rect.top))
      };

      if (current && performance.now() - lastSampleAt > 28) {
        trail.unshift({ x: current.x, y: current.y, time: performance.now() });
        if (trail.length > 24) trail.length = 24;
        lastSampleAt = performance.now();
      } else if (!current) {
        lastSampleAt = performance.now();
      }

      current = next;
      hero.classList.add('spotlight-active');

      if (!frameId) frameId = requestAnimationFrame(renderSpotlight);
    };

    hero.addEventListener('pointerenter', moveSpotlight, { passive: true });
    hero.addEventListener('pointermove', moveSpotlight, { passive: true });
    hero.addEventListener('pointerleave', () => {
      hero.classList.remove('spotlight-active');
      current = null;
      trail.length = 0;
      if (frameId) cancelAnimationFrame(frameId);
      frameId = 0;
      hero.style.removeProperty('--spot-mask');
    });
  }



  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => navigator.serviceWorker.register('./service-worker.js')
      .then(reg => console.log('ConectaPro PWA ativo:', reg.scope))
      .catch(err => console.error('Falha ao registrar Service Worker:', err)));
  }
});
