package br.com.conectapro;

import br.com.conectapro.services.Conexao;
import br.com.conectapro.view.Menu;

import javax.swing.JOptionPane;
import javax.swing.UIManager;
import java.sql.Connection;
import java.sql.SQLException;

/** Ponto de partida: testa a conexão com o MySQL e abre o menu em JOptionPane. */
public class  Main {

    /** Testa a conexão antes de abrir o menu, para avisar cedo se o banco estiver indisponível. */
    public static void main(String[] args) {

        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            // Sem o visual do sistema, usa o padrão do Java.
        }

        try (Connection teste = Conexao.conectar()) {
            // Conexão OK.
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(),
                    "ConectaPro - erro de conexão", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }

        new Menu().iniciar();
        System.exit(0);
    }
}
