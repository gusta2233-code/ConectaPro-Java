package br.com.conectapro.util;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.Base64;

/** Gera o hash (PBKDF2) das senhas: a senha pura nunca vai ao banco. */
public final class SenhaUtil {

    private static final int ITERACOES = 210_000;
    private static final SecureRandom RANDOM = new SecureRandom();

    private SenhaUtil() {
    }

    /**
     * Transforma a senha digitada em um hash com salt aleatório.
     * Formato salvo: PBKDF2$iteracoes$salt$hash (Base64).
     *
     * @throws IllegalArgumentException se a senha tiver menos de 6 caracteres
     */
    public static String gerarHash(String senha) {
        if (senha == null || senha.length() < 6) {
            throw new IllegalArgumentException("A senha deve ter pelo menos 6 caracteres.");
        }
        byte[] salt = new byte[16];
        RANDOM.nextBytes(salt);

        PBEKeySpec spec = new PBEKeySpec(senha.toCharArray(), salt, ITERACOES, 256);
        try {
            byte[] hash = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(spec).getEncoded();
            return "PBKDF2$" + ITERACOES + "$"
                    + Base64.getEncoder().encodeToString(salt) + "$"
                    + Base64.getEncoder().encodeToString(hash);
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("Não foi possível proteger a senha.", e);
        } finally {
            spec.clearPassword();
        }
    }
}
