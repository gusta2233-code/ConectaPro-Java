package br.com.conectapro.controller;

import br.com.conectapro.models.Cliente;
import br.com.conectapro.models.Pessoa;
import br.com.conectapro.models.Profissional;
import br.com.conectapro.models.TipoUsuario;
import br.com.conectapro.services.PessoaService;

import java.sql.SQLException;
import java.util.List;

public class PessoaController {

    private final PessoaService service = new PessoaService();

    public Pessoa cadastrar(TipoUsuario tipo, String nome, String email, String telefone, String cidade, String estado, String senha, String profissao) throws SQLException {
        if (tipo == TipoUsuario.PROFISSIONAL) {
            Profissional p = new Profissional();
            p.setNome(nome);
            p.setEmail(email);
            p.setTelefone(telefone);
            p.setCidade(cidade);
            p.setEstado(estado);
            p.setSenha(senha);
            p.setProfissao(profissao);
            service.cadastrar(p);
            return p;
        } else {
            Cliente c = new Cliente();
            c.setNome(nome);
            c.setEmail(email);
            c.setTelefone(telefone);
            c.setCidade(cidade);
            c.setEstado(estado);
            c.setSenha(senha);
            service.cadastrar(c);
            return c;
        }
    }

    public List<Pessoa> listar() throws SQLException {
        return service.listar();
    }

    public List<Pessoa> listarPorTipo(TipoUsuario tipo) throws SQLException {
        return service.listar().stream()
                .filter(p -> p.getTipo() == tipo)
                .toList();
    }

    public void atualizar(Pessoa pessoa, String nome, String email, String telefone, String cidade, String estado, String novaSenha) throws SQLException {
        pessoa.setNome(nome);
        pessoa.setEmail(email);
        pessoa.setTelefone(telefone);
        pessoa.setCidade(cidade);
        pessoa.setEstado(estado);
        if (novaSenha != null && !novaSenha.isBlank()) {
            pessoa.setSenha(novaSenha);
        }
        service.atualizar(pessoa);
    }

    public void excluir(Pessoa pessoa) throws SQLException {
        service.excluir(pessoa.getId());
    }
}