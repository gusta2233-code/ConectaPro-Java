package br.com.conectapro.controller;

import br.com.conectapro.models.Cliente;
import br.com.conectapro.models.Pessoa;
import br.com.conectapro.models.Servico;
import br.com.conectapro.models.Solicitacao;
import br.com.conectapro.models.StatusSolicitacao;
import br.com.conectapro.services.SolicitacaoService;

import java.sql.SQLException;
import java.util.List;

/** Controller de solicitações: valida o que a View enviou e chama o Service. */
public class SolicitacaoController {

    private final SolicitacaoService service = new SolicitacaoService();

    /**
     * Cadastra uma solicitação para o cliente informado (o serviço é opcional e pode ser null).
     *
     * @throws IllegalArgumentException se o dono não for cliente ou algum dado for inválido
     */
    public Solicitacao cadastrar(Pessoa dono, Servico servico, String titulo, String descricao,
                                 String cidade, String estado) throws SQLException {
        if (!(dono instanceof Cliente cliente)) {
            throw new IllegalArgumentException("Escolha um cliente.");
        }
        Solicitacao solicitacao = new Solicitacao();
        solicitacao.setCliente(cliente);
        solicitacao.setServico(servico);
        preencher(solicitacao, titulo, descricao, cidade, estado);

        service.cadastrar(solicitacao);
        return solicitacao;
    }

    /** Devolve todas as solicitações. */
    public List<Solicitacao> listar() throws SQLException {
        return service.listar();
    }

    /** Atualiza serviço, dados do pedido e status. */
    public void atualizar(Solicitacao solicitacao, Servico servico, String titulo, String descricao,
                          String cidade, String estado, StatusSolicitacao status) throws SQLException {
        solicitacao.setServico(servico);
        preencher(solicitacao, titulo, descricao, cidade, estado);
        solicitacao.setStatus(status);
        service.atualizar(solicitacao);
    }

    /** Exclui a solicitação. */
    public void excluir(Solicitacao solicitacao) throws SQLException {
        service.excluir(solicitacao.getId());
    }

    /** Passa os textos pelos setters, que fazem a validação. */
    private void preencher(Solicitacao s, String titulo, String descricao, String cidade, String estado) {
        s.setTitulo(titulo);
        s.setDescricao(descricao);
        s.setCidade(cidade);
        s.setEstado(estado);
    }
}
