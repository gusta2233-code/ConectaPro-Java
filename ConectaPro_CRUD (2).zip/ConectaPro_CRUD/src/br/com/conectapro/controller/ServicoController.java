package br.com.conectapro.controller;

import br.com.conectapro.models.Categoria;
import br.com.conectapro.models.Pessoa;
import br.com.conectapro.models.Profissional;
import br.com.conectapro.models.Servico;
import br.com.conectapro.services.ServicoService;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

/** Controller de serviços: valida o que a View enviou e chama o Service. */
public class ServicoController {

    private final ServicoService service = new ServicoService();

    /**
     * Cadastra um serviço para o profissional informado.
     *
     * @throws IllegalArgumentException se o dono não for profissional ou algum dado for inválido
     */
    public Servico cadastrar(Pessoa dono, String nome, String descricao,
                             Categoria categoria, String preco) throws SQLException {
        if (!(dono instanceof Profissional profissional)) {
            throw new IllegalArgumentException("Escolha um profissional.");
        }
        Servico servico = new Servico();
        servico.setProfissional(profissional);
        preencher(servico, nome, descricao, categoria, preco);

        service.cadastrar(servico);
        return servico;
    }

    /** Devolve todos os serviços. */
    public List<Servico> listar() throws SQLException {
        return service.listar();
    }

    /** Atualiza nome, descrição, categoria e preço do serviço. */
    public void atualizar(Servico servico, String nome, String descricao,
                          Categoria categoria, String preco) throws SQLException {
        preencher(servico, nome, descricao, categoria, preco);
        service.atualizar(servico);
    }

    /** Exclui o serviço. */
    public void excluir(Servico servico) throws SQLException {
        service.excluir(servico.getId());
    }

    /** Passa os dados pelos setters (validação) e converte o preço digitado, ex.: "150,00". */
    private void preencher(Servico s, String nome, String descricao, Categoria categoria, String preco) {
        s.setNome(nome);
        s.setDescricao(descricao);
        s.setCategoria(categoria);
        try {
            s.setPreco(new BigDecimal(preco.trim().replace(',', '.')));
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Preço inválido. Use apenas números, ex.: 150,00.");
        }
    }
}
