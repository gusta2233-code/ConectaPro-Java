package br.com.conectapro.models;

/** Categorias de serviço que um profissional pode oferecer. */
public enum Categoria {

    ELETRICISTA("Eletricista"),
    ENCANADOR("Encanador"),
    MONTADOR_DE_MOVEIS("Montador de Móveis"),
    PINTOR("Pintor"),
    PEDREIRO("Pedreiro"),
    VIDRACEIRO("Vidraceiro"),
    TECNICO_AR_CONDICIONADO("Técnico de Ar Condicionado"),
    OUTROS("Outros");

    private final String descricao;

    Categoria(String descricao) {
        this.descricao = descricao;
    }

    /** Converte o texto salvo no banco de volta para o enum. */
    public static Categoria deTexto(String texto) {
        for (Categoria c : values()) {
            if (c.descricao.equalsIgnoreCase(texto)) {
                return c;
            }
        }
        return OUTROS;
    }

    @Override
    public String toString() {
        return descricao;
    }
}
