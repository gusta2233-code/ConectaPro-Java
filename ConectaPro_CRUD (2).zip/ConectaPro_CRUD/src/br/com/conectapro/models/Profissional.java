package br.com.conectapro.models;

public class Profissional extends Pessoa {

    private String profissao;

    public Profissional() {
        super();
    }

    public Profissional(int id, String nome, String email, String senha, String telefone, String cidade, String estado, String profissao) {
        super();
        setId(id);
        setNome(nome);
        setEmail(email);
        setSenha(senha);
        setTelefone(telefone);
        setCidade(cidade);
        setEstado(estado);
        setProfissao(profissao);
    }

    @Override
    public TipoUsuario getTipo() {
        return TipoUsuario.PROFISSIONAL;
    }

    public String getProfissao() {
        return profissao;
    }

    public void setProfissao(String profissao) {
        if (profissao == null || profissao.isBlank()) {
            throw new IllegalArgumentException("A profissão é obrigatória para profissionais.");
        }
        this.profissao = profissao.trim();
    }


    @Override
    public String toString() {
        return String.format("%s - %s | Contato: %s | Local: %s/%s",
                getNome(),
                profissao != null ? profissao : "Não informada",
                getTelefone() != null && !getTelefone().isBlank() ? getTelefone() : "Não informado",
                getCidade() != null ? getCidade() : "Não informada",
                getEstado() != null ? getEstado() : "UF"
        );
    }
}