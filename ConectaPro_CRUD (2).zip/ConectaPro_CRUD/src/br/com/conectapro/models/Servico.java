package br.com.conectapro.models;

import java.math.BigDecimal;
import java.util.Locale;

/**
 * Entidade: serviço oferecido por um profissional.
 * Relacionamento: cada serviço pertence a um {@link Profissional}.
 */
public class Servico {

    private int id;
    private Profissional profissional;
    private String nome;
    private String descricao;
    private Categoria categoria;
    private BigDecimal preco;

    public Servico() {
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public Profissional getProfissional() { return profissional; }

    /** O serviço precisa de um profissional responsável. */
    public void setProfissional(Profissional profissional) {
        if (profissional == null) {
            throw new IllegalArgumentException("Escolha um profissional.");
        }
        this.profissional = profissional;
    }

    public String getNome() { return nome; }

    /** O nome do serviço é obrigatório. */
    public void setNome(String nome) {
        if (nome == null || nome.isBlank()) {
            throw new IllegalArgumentException("O nome do serviço é obrigatório.");
        }
        this.nome = nome.trim();
    }

    public String getDescricao() { return descricao; }

    /** A descrição é obrigatória. */
    public void setDescricao(String descricao) {
        if (descricao == null || descricao.isBlank()) {
            throw new IllegalArgumentException("A descrição é obrigatória.");
        }
        this.descricao = descricao.trim();
    }

    public Categoria getCategoria() { return categoria; }
    public void setCategoria(Categoria categoria) { this.categoria = categoria; }

    public BigDecimal getPreco() { return preco; }

    /** O preço deve ser maior que zero (mesma regra do banco). */
    public void setPreco(BigDecimal preco) {
        if (preco == null || preco.signum() <= 0) {
            throw new IllegalArgumentException("O preço deve ser maior que zero.");
        }
        this.preco = preco;
    }

    /** Dois registros são o mesmo quando têm o mesmo id do banco. */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        return id == ((Servico) o).id;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(id);
    }

    @Override
    public String toString() {
        return String.format(Locale.forLanguageTag("pt-BR"),
                "#%d | %s | %s | R$ %.2f | Prof.: %s",
                id, nome, categoria, preco,
                profissional == null ? "-" : profissional.getNome());
    }
}
