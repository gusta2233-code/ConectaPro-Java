package br.com.conectapro.models;

import java.util.Objects;

/**
 * Entidade base de quem usa a plataforma (herança: Cliente e Profissional).
 * As validações ficam nos setters, assim nenhum objeto inválido chega ao banco.
 */
public abstract class Pessoa {

    private int id;
    private String nome;
    private String email;
    private String senha; // sempre o HASH, nunca a senha digitada
    private String telefone;
    private String cidade;
    private String estado;


    public Pessoa() {
    }

    public Pessoa(int id, String nome, String email, String senha,
                  String telefone, String cidade, String estado) {
        this.id = id;
        setNome(nome);
        setEmail(email);
        this.senha = senha;
        setTelefone(telefone);
        setCidade(cidade);
        setEstado(estado);
    }

    /** Cada subclasse informa o seu tipo (polimorfismo). */
    public abstract TipoUsuario getTipo();

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNome() { return nome; }

    /** O nome é obrigatório. */
    public final void setNome(String nome) {
        if (nome == null || nome.isBlank()) {
            throw new IllegalArgumentException("O nome é obrigatório.");
        }
        this.nome = nome.trim();
    }

    public String getEmail() { return email; }

    /** Aceita apenas e-mails no formato texto@dominio.ext e grava em minúsculas. */
    public final void setEmail(String email) {
        if (email == null || !email.trim().matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")) {
            throw new IllegalArgumentException("E-mail inválido.");
        }
        this.email = email.trim().toLowerCase();
    }

    public String getSenha() { return senha; }

    /** Recebe o hash gerado por SenhaUtil, nunca a senha pura. */
    public void setSenha(String senhaHash) { this.senha = senhaHash; }

    public String getTelefone() { return telefone; }

    /** O telefone é opcional: texto em branco vira null. */
    public final void setTelefone(String telefone) {
        this.telefone = (telefone == null || telefone.isBlank()) ? null : telefone.trim();
    }

    public String getCidade() { return cidade; }

    /** A cidade é obrigatória. */
    public final void setCidade(String cidade) {
        if (cidade == null || cidade.isBlank()) {
            throw new IllegalArgumentException("A cidade é obrigatória.");
        }
        this.cidade = cidade.trim();
    }

    public String getEstado() { return estado; }

    /** O estado deve ter exatamente 2 letras (UF) e é gravado em maiúsculas. */
    public final void setEstado(String estado) {
        if (estado == null || !estado.trim().matches("[A-Za-z]{2}")) {
            throw new IllegalArgumentException("Informe o estado com 2 letras (ex.: SC).");
        }
        this.estado = estado.trim().toUpperCase();
    }

    /** Duas pessoas são a mesma quando têm o mesmo e-mail (o e-mail é único no banco). */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        return Objects.equals(email, ((Pessoa) o).email);
    }

    @Override
    public int hashCode() {
        return Objects.hash(email);
    }

    @Override
    public String toString() {
        return "#" + id + " | " + getTipo() + " | " + nome + " | " + email
                + " | " + cidade + "/" + estado;
    }
}
