package br.com.conectapro.models;

/** Entidade: pessoa que procura e solicita serviços. */
public class Cliente extends Pessoa {

    public Cliente() {
    }

    public Cliente(int id, String nome, String email, String senha,
                   String telefone, String cidade, String estado) {
        super(id, nome, email, senha, telefone, cidade, estado);
    }

    @Override
    public TipoUsuario getTipo() {
        return TipoUsuario.CLIENTE;
    }
}
