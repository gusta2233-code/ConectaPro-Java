package br.com.conectapro.models;

/**
 * Entidade: pedido feito por um cliente.
 * Relacionamentos: pertence a um {@link Cliente} e pode estar ligada a um {@link Servico}.
 */
public class Solicitacao {

    private int id;
    private Cliente cliente;
    private Servico servico; // opcional
    private String titulo;
    private String descricao;
    private String cidade;
    private String estado;
    private StatusSolicitacao status = StatusSolicitacao.ABERTA;

    public Solicitacao() {
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public Cliente getCliente() { return cliente; }

    /** A solicitação precisa de um cliente. */
    public void setCliente(Cliente cliente) {
        if (cliente == null) {
            throw new IllegalArgumentException("Escolha um cliente.");
        }
        this.cliente = cliente;
    }

    public Servico getServico() { return servico; }
    public void setServico(Servico servico) { this.servico = servico; }

    public String getTitulo() { return titulo; }

    /** O título é obrigatório. */
    public void setTitulo(String titulo) {
        if (titulo == null || titulo.isBlank()) {
            throw new IllegalArgumentException("O título é obrigatório.");
        }
        this.titulo = titulo.trim();
    }

    public String getDescricao() { return descricao; }

    /** A descrição é obrigatória. */
    public void setDescricao(String descricao) {
        if (descricao == null || descricao.isBlank()) {
            throw new IllegalArgumentException("A descrição é obrigatória.");
        }
        this.descricao = descricao.trim();
    }

    public String getCidade() { return cidade; }

    /** A cidade é obrigatória. */
    public void setCidade(String cidade) {
        if (cidade == null || cidade.isBlank()) {
            throw new IllegalArgumentException("A cidade é obrigatória.");
        }
        this.cidade = cidade.trim();
    }

    public String getEstado() { return estado; }

    /** O estado deve ter 2 letras (UF). */
    public void setEstado(String estado) {
        if (estado == null || !estado.trim().matches("[A-Za-z]{2}")) {
            throw new IllegalArgumentException("Informe o estado com 2 letras (ex.: SC).");
        }
        this.estado = estado.trim().toUpperCase();
    }

    public StatusSolicitacao getStatus() { return status; }
    public void setStatus(StatusSolicitacao status) { this.status = status; }

    /** Dois registros são o mesmo quando têm o mesmo id do banco. */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        return id == ((Solicitacao) o).id;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(id);
    }

    @Override
    public String toString() {
        return "#" + id + " | " + titulo + " | " + status
                + " | Cliente: " + (cliente == null ? "-" : cliente.getNome())
                + " | Serviço: " + (servico == null ? "-" : servico.getNome())
                + " | " + cidade + "/" + estado;
    }
}
