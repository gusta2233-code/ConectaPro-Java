package br.com.conectapro.models;

/**
 * Tipos de usuário usados pelo sistema.
 * (O banco também aceita ADMINISTRADOR, mas o CRUD não trabalha com esse perfil.)
 */
public enum TipoUsuario {
    CLIENTE, PROFISSIONAL
}
