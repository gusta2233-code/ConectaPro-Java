package br.com.conectapro.view;

import javax.swing.*;
import java.util.List;

public class Janelas {

    public static class Cancelado extends RuntimeException {
        public Cancelado() {
            super("Operação cancelada pelo usuário.");
        }
    }

    private void verificarCancelado(Object valor) {
        if (valor == null) {
            throw new Cancelado();
        }
    }

    private void verificarCancelado(int valor) {
        if (valor == JOptionPane.CLOSED_OPTION) {
            throw new Cancelado();
        }
    }

    public int menu(String titulo, String[] opcoes) {
        int escolha = JOptionPane.showOptionDialog(
                null,
                titulo,
                "ConectaPro",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                opcoes,
                opcoes[0]
        );
        verificarCancelado(escolha);
        return escolha;
    }

    @SuppressWarnings("unchecked")
    public <T> T escolherOpcao(String mensagem, T[] opcoes, T inicial) {
        T escolha = (T) JOptionPane.showInputDialog(
                null,
                mensagem,
                "ConectaPro",
                JOptionPane.QUESTION_MESSAGE,
                null,
                opcoes,
                inicial
        );
        verificarCancelado(escolha);
        return escolha;
    }

    public String pedir(String mensagem, String valorAtual) {
        String resposta = (String) JOptionPane.showInputDialog(
                null,
                mensagem,
                "ConectaPro",
                JOptionPane.QUESTION_MESSAGE,
                null,
                null,
                valorAtual
        );
        verificarCancelado(resposta);
        return resposta;
    }

    public String pedirSenha(String mensagem) {
        JPasswordField senhaField = new JPasswordField();
        int opcao = JOptionPane.showConfirmDialog(
                null,
                new Object[]{mensagem, senhaField},
                "ConectaPro",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );
        if (opcao != JOptionPane.OK_OPTION) {
            throw new Cancelado();
        }
        String senha = new String(senhaField.getPassword());
        if (senha.isBlank()) {
            throw new IllegalArgumentException("A senha não pode estar vazia.");
        }
        return senha;
    }

    public void info(String mensagem) {
        JOptionPane.showMessageDialog(null, mensagem, "ConectaPro", JOptionPane.INFORMATION_MESSAGE);
    }

    public void erro(String mensagem) {
        JOptionPane.showMessageDialog(null, mensagem, "Erro - ConectaPro", JOptionPane.ERROR_MESSAGE);
    }

    public void confirmar(String mensagem) {
        int opcao = JOptionPane.showConfirmDialog(
                null,
                mensagem,
                "Confirmação",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );
        if (opcao != JOptionPane.YES_OPTION) {
            throw new Cancelado();
        }
    }

    public void mostrar(String titulo, List<?> lista) {
        if (lista == null || lista.isEmpty()) {
            info("Nenhum registro encontrado.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (Object obj : lista) {
            sb.append(obj.toString()).append("\n-----------------------------------\n");
        }
        JTextArea textArea = new JTextArea(sb.toString(), 20, 40);
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        JOptionPane.showMessageDialog(null, scrollPane, titulo, JOptionPane.INFORMATION_MESSAGE);
    }

    @SuppressWarnings("unchecked")
    public <T> T escolher(String titulo, List<T> lista, String mensagemErro) {
        if (lista == null || lista.isEmpty()) {
            throw new IllegalArgumentException(mensagemErro);
        }

        Object[] array = lista.toArray();

        Object escolhido = JOptionPane.showInputDialog(
                null,                         // parentComponent
                titulo,                       // message
                "ConectaPro",                 // title
                JOptionPane.QUESTION_MESSAGE, // messageType
                null,                         // icon
                array,                        // selectionValues
                array[0]                      // initialSelectionValue
        );

        verificarCancelado(escolhido);
        return (T) escolhido;
    }
}