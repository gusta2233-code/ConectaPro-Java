package br.com.conectapro.view;

import br.com.conectapro.controller.PessoaController;
import br.com.conectapro.controller.ServicoController;
import br.com.conectapro.controller.SolicitacaoController;
import br.com.conectapro.models.Categoria;
import br.com.conectapro.models.Pessoa;
import br.com.conectapro.models.Servico;
import br.com.conectapro.models.Solicitacao;
import br.com.conectapro.models.StatusSolicitacao;
import br.com.conectapro.models.TipoUsuario;

import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

/**
 * Camada View: telas do sistema em JOptionPane.
 * O Menu só pergunta e mostra; as regras ficam nos Controllers e o banco nos Services.
 * Os erros são tratados em um único ponto, o método executar().
 */
public class Menu {

    // Arrays com as opções dos botões.
    private static final String[] MENU_PRINCIPAL = {"Usuários", "Serviços", "Solicitações", "Sair"};
    private static final String[] MENU_CRUD = {"Cadastrar", "Listar", "Atualizar", "Excluir", "Voltar"};

    private final Janelas janelas = new Janelas();
    private final PessoaController pessoaController = new PessoaController();
    private final ServicoController servicoController = new ServicoController();
    private final SolicitacaoController solicitacaoController = new SolicitacaoController();

    /** Uma operação do menu (pode acessar o banco). */
    @FunctionalInterface
    private interface Acao {
        void executar() throws SQLException;
    }

    // ------------------------------------------------------------------
    // MENUS
    // ------------------------------------------------------------------

    /** Exibe o menu principal e repete até o usuário escolher "Sair". */
    public void iniciar() {
        while (true) {
            int opcao = janelas.menu("O que deseja gerenciar?", MENU_PRINCIPAL);

            switch (opcao) {
                case 0 -> submenu("Usuários", this::cadastrarUsuario, this::listarUsuarios,
                        this::atualizarUsuario, this::excluirUsuario);
                case 1 -> submenu("Serviços", this::cadastrarServico, this::listarServicos,
                        this::atualizarServico, this::excluirServico);
                case 2 -> submenu("Solicitações", this::cadastrarSolicitacao, this::listarSolicitacoes,
                        this::atualizarSolicitacao, this::excluirSolicitacao);
                default -> {
                    return; // "Sair" ou janela fechada
                }
            }
        }
    }

    /** Mostra Cadastrar/Listar/Atualizar/Excluir para uma área e executa a ação escolhida. */
    private void submenu(String nome, Acao cadastrar, Acao listar, Acao atualizar, Acao excluir) {
        Acao[] acoes = {cadastrar, listar, atualizar, excluir};

        while (true) {
            int opcao = janelas.menu(nome + " - escolha a operação:", MENU_CRUD);

            if (opcao < 0 || opcao >= acoes.length) {
                return; // "Voltar" ou janela fechada
            }
            executar(acoes[opcao]);
        }
    }

    /**
     * Roda uma operação e trata os erros esperados:
     * cancelamento (volta ao menu), dado inválido (setters) e falha do banco.
     */
    private void executar(Acao acao) {
        try {
            acao.executar();
        } catch (Janelas.Cancelado e) {
            // O usuário desistiu: volta ao menu sem mensagem.
        } catch (IllegalArgumentException e) {
            janelas.erro(e.getMessage());
        } catch (SQLException e) {
            janelas.erro(traduzir(e));
        }
    }

    // ------------------------------------------------------------------
    // USUÁRIOS
    // ------------------------------------------------------------------

    private void cadastrarUsuario() throws SQLException {
        TipoUsuario tipo = janelas.escolherOpcao("Tipo de usuário:", TipoUsuario.values(), TipoUsuario.CLIENTE);
        String nome = janelas.pedir("Nome:", null);

        // Loop para validação do e-mail: mantém o usuário na aba até preencher corretamente
        String email;
        while (true) {
            email = janelas.pedir("E-mail:", null);
            if (email != null && email.contains("@") && email.contains(".") && !email.isBlank()) {
                break; // E-mail válido, sai do loop
            }
            janelas.erro("E-mail inválido! O e-mail deve conter '@' e um domínio válido (ex: teste@email.com).");
        }

        String telefone = janelas.pedir("Telefone (opcional):", null);
        String cidade = janelas.pedir("Cidade:", null);
        String estado = janelas.pedir("Estado (UF):", null);
        String senha = janelas.pedirSenha("Senha (mínimo 6 caracteres):");

        String profissao = null;
        if (tipo == TipoUsuario.PROFISSIONAL) {
            // Escolhe a profissão conforme as opções da aba de Categorias
            Categoria categoriaProfissao = janelas.escolherOpcao("Selecione a Profissão / Categoria:", Categoria.values(), null);
            profissao = categoriaProfissao.name();
        }

        Pessoa pessoa = pessoaController.cadastrar(tipo, nome, email, telefone, cidade, estado, senha, profissao);
        janelas.info("Usuário cadastrado com o ID " + pessoa.getId() + ".");
    }

    private void listarUsuarios() throws SQLException {
        janelas.mostrar("Usuários cadastrados", pessoaController.listar());
    }

    private void atualizarUsuario() throws SQLException {
        Pessoa pessoa = janelas.escolher("Selecione o usuário:", pessoaController.listar(),
                "Nenhum usuário cadastrado.");

        String nome = janelas.pedir("Nome:", pessoa.getNome());
        String email = janelas.pedir("E-mail:", pessoa.getEmail());
        String telefone = janelas.pedir("Telefone (opcional):", pessoa.getTelefone());
        String cidade = janelas.pedir("Cidade:", pessoa.getCidade());
        String estado = janelas.pedir("Estado (UF):", pessoa.getEstado());
        String novaSenha = janelas.pedirSenha("Nova senha (deixe em branco para manter a atual):");

        pessoaController.atualizar(pessoa, nome, email, telefone, cidade, estado, novaSenha);
        janelas.info("Usuário atualizado.");
    }

    private void excluirUsuario() throws SQLException {
        Pessoa pessoa = janelas.escolher("Selecione o usuário:", pessoaController.listar(),
                "Nenhum usuário cadastrado.");
        janelas.confirmar("Excluir " + pessoa.getNome() + "?");
        pessoaController.excluir(pessoa);
        janelas.info("Usuário excluído.");
    }

    // ------------------------------------------------------------------
    // SERVIÇOS
    // ------------------------------------------------------------------

    private void cadastrarServico() throws SQLException {
        Pessoa dono = janelas.escolher("Profissional que oferece o serviço:",
                pessoaController.listarPorTipo(TipoUsuario.PROFISSIONAL),
                "Cadastre um usuário do tipo PROFISSIONAL antes.");

        String nome = janelas.pedir("Nome do serviço:", null);
        String descricao = janelas.pedir("Descrição:", null);
        Categoria categoria = janelas.escolherOpcao("Categoria:", Categoria.values(), null);
        String preco = janelas.pedir("Preço em R$ (ex.: 150,00):", null);

        Servico servico = servicoController.cadastrar(dono, nome, descricao, categoria, preco);
        janelas.info("Serviço cadastrado com o ID " + servico.getId() + ".");
    }

    private void listarServicos() throws SQLException {
        janelas.mostrar("Serviços cadastrados", servicoController.listar());
    }

    private void atualizarServico() throws SQLException {
        Servico servico = janelas.escolher("Selecione o serviço:", servicoController.listar(),
                "Nenhum serviço cadastrado.");

        String nome = janelas.pedir("Nome do serviço:", servico.getNome());
        String descricao = janelas.pedir("Descrição:", servico.getDescricao());
        Categoria categoria = janelas.escolherOpcao("Categoria:", Categoria.values(), servico.getCategoria());
        String preco = janelas.pedir("Preço em R$ (ex.: 150,00):",
                servico.getPreco().toPlainString().replace('.', ','));

        servicoController.atualizar(servico, nome, descricao, categoria, preco);
        janelas.info("Serviço atualizado.");
    }

    private void excluirServico() throws SQLException {
        Servico servico = janelas.escolher("Selecione o serviço:", servicoController.listar(),
                "Nenhum serviço cadastrado.");
        janelas.confirmar("Excluir o serviço " + servico.getNome() + "?");
        servicoController.excluir(servico);
        janelas.info("Serviço excluído.");
    }

    // ------------------------------------------------------------------
    // SOLICITAÇÕES
    // ------------------------------------------------------------------

    private void cadastrarSolicitacao() throws SQLException {
        Pessoa cliente = janelas.escolher("Cliente que está solicitando:",
                pessoaController.listarPorTipo(TipoUsuario.CLIENTE),
                "Cadastre um usuário do tipo CLIENTE antes.");

        Servico servico = escolherServicoOpcional(null);
        String titulo = janelas.pedir("Título:", null);
        String descricao = janelas.pedir("Descrição:", null);
        String cidade = janelas.pedir("Cidade:", null);
        String estado = janelas.pedir("Estado (UF):", null);

        Solicitacao solicitacao = solicitacaoController.cadastrar(cliente, servico, titulo, descricao, cidade, estado);
        janelas.info("Solicitação cadastrada com o ID " + solicitacao.getId() + ".");
    }

    private void listarSolicitacoes() throws SQLException {
        janelas.mostrar("Solicitações", solicitacaoController.listar());
    }

    private void atualizarSolicitacao() throws SQLException {
        Solicitacao solicitacao = janelas.escolher("Selecione a solicitação:", solicitacaoController.listar(),
                "Nenhuma solicitação cadastrada.");

        Servico servico = escolherServicoOpcional(solicitacao.getServico());
        String titulo = janelas.pedir("Título:", solicitacao.getTitulo());
        String descricao = janelas.pedir("Descrição:", solicitacao.getDescricao());
        String cidade = janelas.pedir("Cidade:", solicitacao.getCidade());
        String estado = janelas.pedir("Estado (UF):", solicitacao.getEstado());
        StatusSolicitacao status = janelas.escolherOpcao("Status:", StatusSolicitacao.values(), solicitacao.getStatus());

        solicitacaoController.atualizar(solicitacao, servico, titulo, descricao, cidade, estado, status);
        janelas.info("Solicitação atualizada.");
    }

    private void excluirSolicitacao() throws SQLException {
        Solicitacao solicitacao = janelas.escolher("Selecione a solicitação:", solicitacaoController.listar(),
                "Nenhuma solicitação cadastrada.");
        janelas.confirmar("Excluir a solicitação \"" + solicitacao.getTitulo() + "\"?");
        solicitacaoController.excluir(solicitacao);
        janelas.info("Solicitação excluída.");
    }

    /** Deixa o usuário escolher um serviço ou "nenhum" (o serviço é opcional). */
    private Servico escolherServicoOpcional(Servico atual) throws SQLException {
        List<Servico> servicos = servicoController.listar();
        if (servicos.isEmpty()) {
            return null;
        }

        // Array com a opção "(sem serviço)" na frente dos serviços do banco.
        Object[] opcoes = new Object[servicos.size() + 1];
        opcoes[0] = "(sem serviço)";
        Object inicial = opcoes[0];

        for (int i = 0; i < servicos.size(); i++) {
            opcoes[i + 1] = servicos.get(i);
            if (servicos.get(i).equals(atual)) {
                inicial = opcoes[i + 1];
            }
        }

        Object escolhido = janelas.escolherOpcao("Serviço relacionado (opcional):", opcoes, inicial);
        return (escolhido instanceof Servico) ? (Servico) escolhido : null;
    }

    // ------------------------------------------------------------------
    // ERROS DO BANCO
    // ------------------------------------------------------------------

    /** Troca mensagens técnicas do MySQL por textos que o usuário entende. */
    private String traduzir(SQLException e) {
        String mensagem = (e.getMessage() == null) ? "" : e.getMessage();

        if (e instanceof SQLIntegrityConstraintViolationException) {
            if (mensagem.contains("Duplicate")) {
                return "Já existe um usuário cadastrado com esse e-mail.";
            }
            if (mensagem.contains("Cannot delete")) {
                return "Não é possível excluir: existem registros ligados a este item "
                        + "(exclua antes os serviços ou solicitações dele).";
            }
            return "Os dados não foram aceitos pelo banco (registro relacionado inexistente).";
        }
        return "Erro no banco de dados:\n" + mensagem;
    }
}
