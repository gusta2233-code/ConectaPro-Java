package br.com.conectapro.services;

import br.com.conectapro.models.Cliente;
import br.com.conectapro.models.Pessoa;
import br.com.conectapro.models.Profissional;
import br.com.conectapro.models.TipoUsuario;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/** Camada de serviços (JDBC): CRUD da tabela usuarios (clientes e profissionais). */
public class PessoaService {

    /**
     * CREATE: grava um novo usuário e preenche o id gerado pelo banco no objeto.
     * Inclui a profissão se o usuário for do tipo PROFISSIONAL.
     *
     * @throws SQLException e-mail repetido ou falha de conexão
     */
    public void cadastrar(Pessoa p) throws SQLException {
        String sql = "INSERT INTO usuarios (nome, email, senha, telefone, tipo, cidade, estado, profissao) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, p.getNome());
            ps.setString(2, p.getEmail());
            ps.setString(3, p.getSenha());
            ps.setString(4, p.getTelefone());
            ps.setString(5, p.getTipo().name());
            ps.setString(6, p.getCidade());
            ps.setString(7, p.getEstado());

            // Grava a profissão apenas se for Profissional
            if (p instanceof Profissional prof) {
                ps.setString(8, prof.getProfissao());
            } else {
                ps.setString(8, null);
            }

            ps.executeUpdate();

            try (ResultSet chaves = ps.getGeneratedKeys()) {
                if (chaves.next()) {
                    p.setId(chaves.getInt(1));
                }
            }
        }
    }

    /** READ: devolve todos os clientes e profissionais, em ordem alfabética. */
    public List<Pessoa> listar() throws SQLException {
        return consultar(null);
    }

    /** READ: devolve apenas os usuários do tipo informado. */
    public List<Pessoa> listarPorTipo(TipoUsuario tipo) throws SQLException {
        return consultar(tipo);
    }

    /** Consulta comum a listar() e listarPorTipo(); tipo null significa "todos". */
    private List<Pessoa> consultar(TipoUsuario tipo) throws SQLException {
        List<Pessoa> lista = new ArrayList<>();

        String sql = "SELECT id_usuario, nome, email, senha, telefone, tipo, cidade, estado, profissao "
                + "FROM usuarios WHERE tipo IN ('CLIENTE', 'PROFISSIONAL') " // ignora o perfil ADMINISTRADOR
                + (tipo != null ? "AND tipo = ? " : "")
                + "ORDER BY nome ";

        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            if (tipo != null) {
                ps.setString(1, tipo.name());
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(montar(rs));
                }
            }
        }
        return lista;
    }

    /** UPDATE: altera os dados do usuário (incluindo a profissão se for Profissional). */
    public void atualizar(Pessoa p) throws SQLException {
        String sql = "UPDATE usuarios SET nome = ?, email = ?, senha = ?, telefone = ?, "
                + "cidade = ?, estado = ?, profissao = ? WHERE id_usuario = ?";

        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, p.getNome());
            ps.setString(2, p.getEmail());
            ps.setString(3, p.getSenha());
            ps.setString(4, p.getTelefone());
            ps.setString(5, p.getCidade());
            ps.setString(6, p.getEstado());

            if (p instanceof Profissional prof) {
                ps.setString(7, prof.getProfissao());
            } else {
                ps.setString(7, null);
            }

            ps.setInt(8, p.getId());
            ps.executeUpdate();
        }
    }

    /**
     * DELETE: remove o usuário pelo id.
     *
     * @throws SQLException se ainda existirem serviços ou solicitações ligados a ele
     */
    public void excluir(int id) throws SQLException {
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement("DELETE FROM usuarios WHERE id_usuario = ?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    /** Transforma uma linha do banco em Cliente ou Profissional. */
    private Pessoa montar(ResultSet rs) throws SQLException {
        TipoUsuario tipo = TipoUsuario.valueOf(rs.getString("tipo"));
        int id = rs.getInt("id_usuario");

        try {
            if (tipo == TipoUsuario.CLIENTE) {
                return new Cliente(id, rs.getString("nome"), rs.getString("email"),
                        rs.getString("senha"), rs.getString("telefone"),
                        rs.getString("cidade"), rs.getString("estado"));
            }

            return new Profissional(id, rs.getString("nome"), rs.getString("email"),
                    rs.getString("senha"), rs.getString("telefone"),
                    rs.getString("cidade"), rs.getString("estado"),
                    rs.getString("profissao"));

        } catch (IllegalArgumentException e) {
            throw new SQLException("Usuário #" + id + " tem dados incompletos no banco: " + e.getMessage());
        }
    }
}