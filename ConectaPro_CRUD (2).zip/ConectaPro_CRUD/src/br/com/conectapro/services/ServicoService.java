package br.com.conectapro.services;

import br.com.conectapro.models.Categoria;
import br.com.conectapro.models.Profissional;
import br.com.conectapro.models.Servico;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/** Camada de serviços (JDBC): CRUD da tabela servicos. */
public class ServicoService {

    /** CREATE: grava um novo serviço (o profissional precisa existir) e preenche o id gerado. */
    public void cadastrar(Servico s) throws SQLException {
        String sql = "INSERT INTO servicos (id_profissional, nome, descricao, categoria, preco) "
                + "VALUES (?, ?, ?, ?, ?)";

        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, s.getProfissional().getId());
            ps.setString(2, s.getNome());
            ps.setString(3, s.getDescricao());
            ps.setString(4, s.getCategoria().toString());
            ps.setBigDecimal(5, s.getPreco());
            ps.executeUpdate();

            try (ResultSet chaves = ps.getGeneratedKeys()) {
                if (chaves.next()) {
                    s.setId(chaves.getInt(1));
                }
            }
        }
    }

    /** READ: devolve os serviços com o nome do profissional (JOIN com usuarios), em ordem alfabética. */
    public List<Servico> listar() throws SQLException {
        List<Servico> lista = new ArrayList<>();

        String sql = "SELECT s.id_servico, s.nome, s.descricao, s.categoria, s.preco, "
                + "u.id_usuario, u.nome AS nome_profissional "
                + "FROM servicos s INNER JOIN usuarios u ON s.id_profissional = u.id_usuario "
                + "ORDER BY s.nome";

        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Profissional prof = new Profissional();
                prof.setId(rs.getInt("id_usuario"));
                prof.setNome(rs.getString("nome_profissional"));

                Servico s = new Servico();
                s.setId(rs.getInt("id_servico"));
                s.setProfissional(prof);
                s.setNome(rs.getString("nome"));
                s.setDescricao(rs.getString("descricao"));
                s.setCategoria(Categoria.deTexto(rs.getString("categoria")));
                s.setPreco(rs.getBigDecimal("preco"));
                lista.add(s);
            }
        }
        return lista;
    }

    /** UPDATE: altera nome, descrição, categoria e preço do serviço. */
    public void atualizar(Servico s) throws SQLException {
        String sql = "UPDATE servicos SET nome = ?, descricao = ?, categoria = ?, preco = ? "
                + "WHERE id_servico = ?";

        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, s.getNome());
            ps.setString(2, s.getDescricao());
            ps.setString(3, s.getCategoria().toString());
            ps.setBigDecimal(4, s.getPreco());
            ps.setInt(5, s.getId());
            ps.executeUpdate();
        }
    }

    /**
     * DELETE: remove o serviço pelo id.
     *
     * @throws SQLException se alguma solicitação ainda estiver ligada a ele
     */
    public void excluir(int id) throws SQLException {
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement("DELETE FROM servicos WHERE id_servico = ?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
}
