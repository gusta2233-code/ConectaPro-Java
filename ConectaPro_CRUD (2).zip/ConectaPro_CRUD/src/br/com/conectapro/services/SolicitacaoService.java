package br.com.conectapro.services;

import br.com.conectapro.models.Cliente;
import br.com.conectapro.models.Servico;
import br.com.conectapro.models.Solicitacao;
import br.com.conectapro.models.StatusSolicitacao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

/** Camada de serviços (JDBC): CRUD da tabela solicitacoes. */
public class SolicitacaoService {

    /** CREATE: grava uma nova solicitação (serviço opcional) e preenche o id gerado. */
    public void cadastrar(Solicitacao s) throws SQLException {
        String sql = "INSERT INTO solicitacoes "
                + "(id_cliente, id_servico, titulo, descricao, cidade, estado, status) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, s.getCliente().getId());
            definirServico(ps, 2, s);
            ps.setString(3, s.getTitulo());
            ps.setString(4, s.getDescricao());
            ps.setString(5, s.getCidade());
            ps.setString(6, s.getEstado());
            ps.setString(7, s.getStatus().name());
            ps.executeUpdate();

            try (ResultSet chaves = ps.getGeneratedKeys()) {
                if (chaves.next()) {
                    s.setId(chaves.getInt(1));
                }
            }
        }
    }

    /** READ: devolve as solicitações (mais recentes primeiro) com o nome do cliente e do serviço. */
    public List<Solicitacao> listar() throws SQLException {
        List<Solicitacao> lista = new ArrayList<>();

        String sql = "SELECT s.id_solicitacao, s.id_cliente, s.id_servico, s.titulo, s.descricao, "
                + "s.cidade, s.estado, s.status, "
                + "u.nome AS nome_cliente, sv.nome AS nome_servico "
                + "FROM solicitacoes s "
                + "INNER JOIN usuarios u ON s.id_cliente = u.id_usuario "
                + "LEFT JOIN servicos sv ON s.id_servico = sv.id_servico "
                + "ORDER BY s.data_solicitacao DESC";

        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Cliente cliente = new Cliente();
                cliente.setId(rs.getInt("id_cliente"));
                cliente.setNome(rs.getString("nome_cliente"));

                Solicitacao s = new Solicitacao();
                s.setId(rs.getInt("id_solicitacao"));
                s.setCliente(cliente);

                int idServico = rs.getInt("id_servico");
                if (!rs.wasNull()) {
                    Servico servico = new Servico();
                    servico.setId(idServico);
                    servico.setNome(rs.getString("nome_servico"));
                    s.setServico(servico);
                }

                s.setTitulo(rs.getString("titulo"));
                s.setDescricao(rs.getString("descricao"));
                s.setCidade(rs.getString("cidade"));
                s.setEstado(rs.getString("estado"));
                s.setStatus(StatusSolicitacao.valueOf(rs.getString("status")));
                lista.add(s);
            }
        }
        return lista;
    }

    /** UPDATE: altera serviço, título, descrição, local e status da solicitação. */
    public void atualizar(Solicitacao s) throws SQLException {
        String sql = "UPDATE solicitacoes SET id_servico = ?, titulo = ?, descricao = ?, "
                + "cidade = ?, estado = ?, status = ? WHERE id_solicitacao = ?";

        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            definirServico(ps, 1, s);
            ps.setString(2, s.getTitulo());
            ps.setString(3, s.getDescricao());
            ps.setString(4, s.getCidade());
            ps.setString(5, s.getEstado());
            ps.setString(6, s.getStatus().name());
            ps.setInt(7, s.getId());
            ps.executeUpdate();
        }
    }

    /** DELETE: remove a solicitação pelo id. */
    public void excluir(int id) throws SQLException {
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement("DELETE FROM solicitacoes WHERE id_solicitacao = ?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    /** O serviço é opcional: sem serviço, grava NULL. */
    private void definirServico(PreparedStatement ps, int posicao, Solicitacao s) throws SQLException {
        if (s.getServico() != null) {
            ps.setInt(posicao, s.getServico().getId());
        } else {
            ps.setNull(posicao, Types.INTEGER);
        }
    }
}
