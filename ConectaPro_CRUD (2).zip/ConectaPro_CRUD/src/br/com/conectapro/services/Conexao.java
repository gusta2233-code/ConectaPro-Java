package br.com.conectapro.services;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Abre a conexão JDBC com o MySQL.
 * Usuário, senha e URL ficam em config.properties (na pasta do projeto).
 */
public final class Conexao {

    private Conexao() {
    }

    /**
     * Abre uma nova conexão com o banco usando os dados do config.properties.
     * Quem chama deve fechar a conexão (use try-with-resources).
     *
     * @throws SQLException se o arquivo não existir, estiver incompleto ou o MySQL recusar a conexão
     */
    public static Connection conectar() throws SQLException {

        Path arquivo = Path.of(System.getProperty("user.dir"), "config.properties");

        if (!Files.isRegularFile(arquivo)) {
            throw new SQLException("Arquivo config.properties não encontrado em:\n"
                    + arquivo.getParent()
                    + "\n\nCopie config.properties.example para config.properties "
                    + "e informe a senha do MySQL.");
        }

        Properties config = new Properties();
        try (InputStream entrada = Files.newInputStream(arquivo)) {
            config.load(entrada);
        } catch (IOException e) {
            throw new SQLException("Não foi possível ler o config.properties.", e);
        }

        String url = config.getProperty("db.url");
        String usuario = config.getProperty("db.user");
        String senha = config.getProperty("db.password");

        if (url == null || usuario == null || senha == null) {
            throw new SQLException("Configuração incompleta: confira db.url, db.user e db.password.");
        }

        try {
            return DriverManager.getConnection(url.trim(), usuario.trim(), senha);
        } catch (SQLException e) {
            throw new SQLException(
                    "Erro ao conectar ao MySQL: " + e.getMessage(), e
            );
        }
    }
}
