-- Banco do ConectaPro (mesmo esquema do trabalho original).
-- Pode ser executado mais de uma vez: usa IF NOT EXISTS.

CREATE DATABASE IF NOT EXISTS conectapro;
USE conectapro;

CREATE TABLE IF NOT EXISTS usuarios (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    telefone VARCHAR(20),
    tipo ENUM('CLIENTE', 'PROFISSIONAL', 'ADMINISTRADOR') NOT NULL,
    cidade VARCHAR(100),
    estado CHAR(2),
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS servicos (
    id_servico INT AUTO_INCREMENT PRIMARY KEY,
    id_profissional INT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    descricao TEXT NOT NULL,
    categoria VARCHAR(80) NOT NULL,
    preco DECIMAL(10,2) NOT NULL,
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_servico_profissional
        FOREIGN KEY (id_profissional) REFERENCES usuarios(id_usuario),
    CHECK (preco > 0)
);

CREATE TABLE IF NOT EXISTS solicitacoes (
    id_solicitacao INT AUTO_INCREMENT PRIMARY KEY,
    id_cliente INT NOT NULL,
    id_servico INT,
    titulo VARCHAR(120) NOT NULL,
    descricao TEXT NOT NULL,
    cidade VARCHAR(100) NOT NULL,
    estado CHAR(2) NOT NULL,
    status ENUM('ABERTA', 'EM_ANDAMENTO', 'CONCLUIDA', 'CANCELADA') DEFAULT 'ABERTA',
    data_solicitacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_solicitacao_cliente
        FOREIGN KEY (id_cliente) REFERENCES usuarios(id_usuario),
    CONSTRAINT fk_solicitacao_servico
        FOREIGN KEY (id_servico) REFERENCES servicos(id_servico)
);

SELECT * FROM usuarios


